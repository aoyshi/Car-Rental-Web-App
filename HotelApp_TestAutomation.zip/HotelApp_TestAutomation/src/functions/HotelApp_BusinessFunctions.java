package functions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.Properties;

public class HotelApp_BusinessFunctions {
	
  public static WebDriver driver;
  public static Properties prop;
	
  public void HA_BF_Login(WebDriver driver, String sUsername, String sPassword)
  {
	//provide user-name
	driver.findElement(By.xpath(prop.getProperty("Txt_Login_Username"))).clear();
	driver.findElement(By.xpath(prop.getProperty("Txt_Login_Username"))).sendKeys(sUsername);
	
	//provide password
	driver.findElement(By.id(prop.getProperty("Txt_Login_Password"))).clear();
	driver.findElement(By.id(prop.getProperty("Txt_Login_Password"))).sendKeys(sPassword);
	
	//click on login
	driver.findElement(By.id(prop.getProperty("Btn_Login_Login"))).click();
  
  }
  
  public void HA_BF_searchHotel(WebDriver driver, String hotel, String roomNos, String adults) {
	    new Select(driver.findElement(By.id(prop.getProperty("Lst_SearchHotel_Location")))).selectByVisibleText(hotel);
	    new Select(driver.findElement(By.id(prop.getProperty("Lst_SearchHotel_Room_Nos")))).selectByVisibleText(roomNos);
	    new Select(driver.findElement(By.id(prop.getProperty("Lst_SearchHotel_Adult_Room")))).selectByVisibleText(adults);
	    driver.findElement(By.id(prop.getProperty("Btn_SearchHotel_Search"))).click();	    
  }
  
  public void HA_BF_searchHotel(WebDriver driver,String location,String hotelName,String roomType,
		  String numberRooms,String checkIn,String checkOut,String noAdults,String noChild) {
	  
	    new Select(driver.findElement(By.id(prop.getProperty("Lst_SearchHotel_Location")))).selectByVisibleText(location);
	    new Select(driver.findElement(By.id(prop.getProperty("Lst_SearchHotel_Hotels")))).selectByVisibleText(hotelName);
	    new Select(driver.findElement(By.id(prop.getProperty("Lst_SearchHotel_Room_Type")))).selectByVisibleText(roomType);
	    new Select(driver.findElement(By.id(prop.getProperty("Lst_SearchHotel_Room_Nos")))).selectByVisibleText(numberRooms);
	    
	    driver.findElement(By.id(prop.getProperty("Lst_SearchHotel_Check_In_Date"))).clear();
	    driver.findElement(By.id(prop.getProperty("Lst_SearchHotel_Check_In_Date"))).sendKeys(checkIn);
	    driver.findElement(By.id(prop.getProperty("Lst_SearchHotel_Check_Out_Date"))).clear();
	    driver.findElement(By.id(prop.getProperty("Lst_SearchHotel_Check_Out_Date"))).sendKeys(checkOut);
	    
	    new Select(driver.findElement(By.id(prop.getProperty("Lst_SearchHotel_Adult_Room")))).selectByVisibleText(noAdults);
	    new Select(driver.findElement(By.id(prop.getProperty("Lst_SearchHotel_Child_Room")))).selectByVisibleText(noChild);
	    driver.findElement(By.id(prop.getProperty("Btn_SearchHotel_Search"))).click();	
  }
  
  public void HA_BF_bookHotel(WebDriver driver, String firstName, String lastName, String address, String ccNum,
		  String ccType, String ccExpMonth, String ccExpYear, String cvv) {
	  
	    driver.findElement(By.id(prop.getProperty("Txt_BookingHotel_FirstName"))).clear();
	    driver.findElement(By.id(prop.getProperty("Txt_BookingHotel_FirstName"))).sendKeys(firstName);
	    driver.findElement(By.id(prop.getProperty("Txt_BookingHotel_LastName"))).clear();
	    driver.findElement(By.id(prop.getProperty("Txt_BookingHotel_LastName"))).sendKeys(lastName);
	    driver.findElement(By.id(prop.getProperty("Txt_BookingHotel_Address"))).clear();
	    driver.findElement(By.id(prop.getProperty("Txt_BookingHotel_Address"))).sendKeys(address);
	    driver.findElement(By.id(prop.getProperty("Txt_BookingHotel_CCNumber"))).clear();
	    driver.findElement(By.id(prop.getProperty("Txt_BookingHotel_CCNumber"))).sendKeys(ccNum);
	    new Select(driver.findElement(By.id(prop.getProperty("Lst_BookingHotel_CCType")))).selectByVisibleText(ccType);
	    new Select(driver.findElement(By.id(prop.getProperty("Lst_BookingHotel_CCExpMonth")))).selectByVisibleText(ccExpMonth);
	    new Select(driver.findElement(By.id(prop.getProperty("Lst_BookingHotel_CCExpYear")))).selectByVisibleText(ccExpYear);
	    driver.findElement(By.id(prop.getProperty("Txt_BookingHotel_CCCvvNumber"))).clear();
	    driver.findElement(By.id(prop.getProperty("Txt_BookingHotel_CCCvvNumber"))).sendKeys(cvv);
	    
	    driver.findElement(By.id(prop.getProperty("Btn_BookingHotel_BookNow"))).click();
	    
  }
	
}
