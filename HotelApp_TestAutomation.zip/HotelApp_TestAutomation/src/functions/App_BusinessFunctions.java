package functions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Properties;

public class App_BusinessFunctions {
	
  public static WebDriver driver;
  public static Properties prop;
	
  public void App_BF_Login(WebDriver driver, String sUsername, String sPassword)
  {
	//provide user-name
	driver.findElement(By.id(prop.getProperty("Txt_Login_Username"))).clear();
	driver.findElement(By.id(prop.getProperty("Txt_Login_Username"))).sendKeys(sUsername);
	
	//provide password
	driver.findElement(By.id(prop.getProperty("Txt_Login_Password"))).clear();
	driver.findElement(By.id(prop.getProperty("Txt_Login_Password"))).sendKeys(sPassword);
	
	//click on login
	driver.findElement(By.id(prop.getProperty("Btn_Login_Login"))).click();
  
  }
  
  public void App_BF_Logout(WebDriver driver) {
	  //click on logout link
		driver.findElement(By.linkText(prop.getProperty("Lnk_Home_Logout"))).click();

  }
  
}
