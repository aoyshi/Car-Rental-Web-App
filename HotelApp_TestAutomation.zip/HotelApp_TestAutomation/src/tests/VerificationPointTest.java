package tests;

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class VerificationPointTest {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
//	MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    baseUrl = "http://adactin.com/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testM15Exercise() throws Exception {
    driver.get(baseUrl + "/HotelApp/index.php");
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("arunika7");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("Hi..There..001");
    driver.findElement(By.id("login")).click();
    
    //check title
    //assertEquals("AdactIn.com - Search Hotel",driver.getTitle()); 
    
    new Select(driver.findElement(By.id("location"))).selectByVisibleText("Sydney");
    new Select(driver.findElement(By.id("hotels"))).selectByVisibleText("Hotel Hervey");
    new Select(driver.findElement(By.id("room_type"))).selectByVisibleText("Super Deluxe");
    driver.findElement(By.id("datepick_out")).clear();
    driver.findElement(By.id("datepick_out")).sendKeys("25/10/2018");
    driver.findElement(By.id("Submit")).click();
    
    //String slocation = driver.findElement(By.xpath(".//*[@id='location_1']")).getAttribute("value");
    //dont use this: assertEquals("Sydney",slocation); - compares obj mem location, not obj itself
    //Assert:
    //assertTrue(slocation.equals("Sydney")); 
    
    driver.findElement(By.id("radiobutton_0")).click();
    
    String nightlyPriceAsString = driver.findElement(By.id("total_price_0")).getAttribute("value");
    int nightlyPrice = Integer.parseInt(nightlyPriceAsString.replace("AUD $ ",""));
    int totalPrice = nightlyPrice * 7 + 10;
    String totalPriceAsString = "AUD $ "+totalPrice;
    
    try {
      assertEquals(totalPriceAsString, driver.findElement(By.id("total_price_0")).getAttribute("value"));
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    
    driver.findElement(By.id("continue")).click();
    driver.findElement(By.id("first_name")).clear();
    driver.findElement(By.id("first_name")).sendKeys("arunika");
    driver.findElement(By.id("last_name")).clear();
    driver.findElement(By.id("last_name")).sendKeys("oyshi");
    driver.findElement(By.id("address")).clear();
    driver.findElement(By.id("address")).sendKeys("123 avenue, arlington, tx 76016");
    driver.findElement(By.id("cc_num")).clear();
    driver.findElement(By.id("cc_num")).sendKeys("1000969278000000");
    new Select(driver.findElement(By.id("cc_type"))).selectByVisibleText("American Express");
    new Select(driver.findElement(By.id("cc_exp_month"))).selectByVisibleText("December");
    new Select(driver.findElement(By.id("cc_exp_year"))).selectByVisibleText("2018");
    driver.findElement(By.id("cc_cvv")).clear();
    driver.findElement(By.id("cc_cvv")).sendKeys("9278");
    driver.findElement(By.id("book_now")).click();
    driver.findElement(By.linkText("Logout")).click();
    driver.findElement(By.linkText("Click here to login again")).click();
  }

//  @After
//  public void tearDown() throws Exception {
//    driver.quit();
//    String verificationErrorString = verificationErrors.toString();
//    if (!"".equals(verificationErrorString)) {
//      fail(verificationErrorString);
//    }
//  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
