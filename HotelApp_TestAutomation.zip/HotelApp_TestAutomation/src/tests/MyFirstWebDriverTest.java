package tests;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class MyFirstWebDriverTest {
  private WebDriver driver;
  private String baseUrl;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
//	MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    baseUrl = "http://adactin.com/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testMyFirstWebDriver() throws Exception {
    driver.get(baseUrl + "/HotelApp/");
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("arunika7");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("Hi..There..001");
    driver.findElement(By.id("login")).click();
    
    //check title
    assertEquals("AdactIn.com - Search Hotel",driver.getTitle()); 
    
    new Select(driver.findElement(By.id("location"))).selectByVisibleText("Sydney");
    new Select(driver.findElement(By.id("room_nos"))).selectByVisibleText("2 - Two");
    new Select(driver.findElement(By.id("adult_room"))).selectByVisibleText("2 - Two");
    driver.findElement(By.id("Submit")).click();
    
    String slocation = driver.findElement(By.xpath(".//*[@id='location_1']")).getAttribute("value");
    //dont use this: assertEquals("Sydney",slocation); - compares obj mem location, not obj itself
    //Assert:
    assertTrue(slocation.equals("Sydney")); 
    
    //Verify:
    //try { assertTrue(slocation.equals("Blaaa")); }
    //catch (Error e) { }
    
    driver.findElement(By.id("radiobutton_1")).click();
    driver.findElement(By.id("continue")).click();
    driver.findElement(By.id("first_name")).clear();
    driver.findElement(By.id("first_name")).sendKeys("James");
    driver.findElement(By.id("last_name")).clear();
    driver.findElement(By.id("last_name")).sendKeys("Dummy");
    driver.findElement(By.id("address")).clear();
    driver.findElement(By.id("address")).sendKeys("1234 Anywhere Ln\nCity, St 12345");
    driver.findElement(By.id("cc_num")).clear();
    driver.findElement(By.id("cc_num")).sendKeys("0001000200030004");
    new Select(driver.findElement(By.id("cc_type"))).selectByVisibleText("Master Card");
    new Select(driver.findElement(By.id("cc_exp_month"))).selectByVisibleText("January");
    new Select(driver.findElement(By.id("cc_exp_year"))).selectByVisibleText("2019");
    driver.findElement(By.id("cc_cvv")).clear();
    driver.findElement(By.id("cc_cvv")).sendKeys("123");
    driver.findElement(By.id("book_now")).click();
    driver.findElement(By.linkText("Logout")).click();
    driver.findElement(By.linkText("Click here to login again")).click();
}

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }
}