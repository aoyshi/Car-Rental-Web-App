package tests;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import java.util.Properties;
import java.io.FileInputStream;
import functions.HotelApp_BusinessFunctions;

public class ConfigurationFileTest extends HotelApp_BusinessFunctions {
	
  //private WebDriver driver;
  //private String baseUrl;
  private StringBuffer verificationErrors = new StringBuffer();
  //public Properties prop;
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
//	MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    //baseUrl = "http://adactin.com/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));

    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));

  }

  @Test
  public void testFunctionCallingTest() throws Exception {
	//login
    driver.get(sAppURL);
    HA_BF_Login(driver,"arunika7","Hi..There..001");
  
    //search hotel page
    HA_BF_searchHotel(driver,"Sydney","2 - Two","2 - Two");

    //select hotel page
    driver.findElement(By.id(prop.getProperty("Rad_SelectHotel_RadioButton_1"))).click();
    driver.findElement(By.id(prop.getProperty("Btn_SelectHotel_Continue"))).click();
    
    //booking page
    HA_BF_bookHotel(driver,"Arunika","Oyshi","123 Anywhere Ln", "0001000200030004","Master Card",
    		"December","2018","9278");

    //logout
    driver.findElement(By.linkText(prop.getProperty("Lnk_BookingHotel_Logout"))).click();
    driver.findElement(By.linkText(prop.getProperty("Lnk_Logout_ClickHeretoLoginAgain"))).click();
}

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }
}