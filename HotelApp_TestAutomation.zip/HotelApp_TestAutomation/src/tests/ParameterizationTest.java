package tests;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.Before;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import java.util.Properties;
import java.io.FileInputStream;
import functions.HotelApp_BusinessFunctions;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

import org.junit.runner.RunWith;

@RunWith(JUnitParamsRunner.class)
public class ParameterizationTest extends HotelApp_BusinessFunctions {

	  private StringBuffer verificationErrors = new StringBuffer();
	  public static String sAppURL, sSharedUIMapPath; 
	  
	  @Before
	  public void setUp() throws Exception {
//		MAGIC CODE GOES HERE 
		System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
	    driver = new FirefoxDriver();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    prop = new Properties();
	    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));

	    sAppURL = prop.getProperty("sAppURL");
	    sSharedUIMapPath = prop.getProperty("SharedUIMap");
	    prop.load(new FileInputStream(sSharedUIMapPath));

	  }
	
	@FileParameters("src/Search_Hotel.csv")
	@Test
	public void testParameterization(int testCaseNo, String location, String hotelName,
			String roomType, String numberRooms, String checkIn, String checkOut, String noAdults,
			String noChild, String ExpPriceNight, String ExpTotalPrice) throws Exception {
		
		driver.get(sAppURL);
		HA_BF_Login(driver, "arunika7","Hi..There..001");
		HA_BF_searchHotel(driver,location,hotelName,roomType,numberRooms,checkIn,checkOut,
				noAdults,noChild);
		
		String actualPerNight = driver.findElement(By.id("price_night_0")).getAttribute("value");
		String totalPrice = driver.findElement(By.id("total_price_0")).getAttribute("value");
		
		assertEquals(ExpPriceNight,actualPerNight);
		assertEquals(ExpTotalPrice,totalPrice);
		
		//logout
	    driver.findElement(By.linkText(prop.getProperty("Lnk_BookingHotel_Logout"))).click();
	    driver.findElement(By.linkText(prop.getProperty("Lnk_Logout_ClickHeretoLoginAgain"))).click();
			
	}
	  @After
	  public void tearDown() throws Exception {
	    driver.quit();
	    String verificationErrorString = verificationErrors.toString();
	    if (!"".equals(verificationErrorString)) {
	      fail(verificationErrorString);
	    }
	  }
	

}
