package tests;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.Before;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Properties;
import java.io.FileInputStream;
import functions.HotelApp_BusinessFunctions;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

import org.junit.runner.RunWith;

@RunWith(JUnitParamsRunner.class)
public class DynamicUIObjectTest extends HotelApp_BusinessFunctions {

	  private StringBuffer verificationErrors = new StringBuffer();
	  public static String sAppURL, sSharedUIMapPath; 
	  
	  @Before
	  public void setUp() throws Exception {
//		MAGIC CODE GOES HERE 
		System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
	    driver = new FirefoxDriver();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    prop = new Properties();
	    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));

	    sAppURL = prop.getProperty("sAppURL");
	    sSharedUIMapPath = prop.getProperty("SharedUIMap");
	    prop.load(new FileInputStream(sSharedUIMapPath));

	  }
	
	@FileParameters("src/Search_Hotel.csv")
	@Test
	public void testParameterization(int testCaseNo, String location, String hotelName,
			String roomType, String numberRooms, String checkIn, String checkOut, String noAdults,
			String noChild, String ExpPriceNight, String ExpTotalPrice) throws Exception {
		
		driver.get(sAppURL);
		HA_BF_Login(driver, "arunika7","Hi..There..001");
		HA_BF_searchHotel(driver,location,hotelName,roomType,numberRooms,checkIn,checkOut,
				noAdults,noChild);
		driver.findElement(By.id(prop.getProperty("Rad_SelectHotel_RadioButton_0"))).click();
		driver.findElement(By.id(prop.getProperty("Btn_SelectHotel_Continue"))).click();
		
		//booking 
	    HA_BF_bookHotel(driver,"Arunika","Oyshi","123 Anywhere Ln", "0001000200030004","Master Card",
	    		"December","2018","9278");
		
	    WebDriverWait myWaitVar = new WebDriverWait(driver,10);
	    myWaitVar.until(ExpectedConditions.visibilityOfElementLocated(By.id(prop.getProperty("Btn_BookingHotel_Logout"))));
	    
	    String strOrderNo = driver.findElement(By.id(prop.getProperty("Txt_BookingHotel_OrderNo"))).getAttribute("value");
		System.out.println("Order Number generated is "+strOrderNo);
	    
		driver.findElement(By.id(prop.getProperty("Btn_BookingHotel_MyItinerary"))).click();
		driver.findElement(By.id(prop.getProperty("Txt_BookedItinerary_SearchOrderid"))).sendKeys(strOrderNo);
		driver.findElement(By.id(prop.getProperty("Btn_BookedItinerary_Go"))).click();
		Thread.sleep(10_000);
		
		driver.findElement(By.xpath(".//*[@value='Cancel "+ strOrderNo +"']")).click();
		
		Alert javascriptAlert = driver.switchTo().alert();
		System.out.println(javascriptAlert.getText());
		javascriptAlert.accept();

		
		//logout
	    driver.findElement(By.linkText(prop.getProperty("Lnk_BookingHotel_Logout"))).click();
	    driver.findElement(By.linkText(prop.getProperty("Lnk_Logout_ClickHeretoLoginAgain"))).click();
			
	}
	  @After
	  public void tearDown() throws Exception {
	    driver.quit();
	    String verificationErrorString = verificationErrors.toString();
	    if (!"".equals(verificationErrorString)) {
	      fail(verificationErrorString);
	    }
	  }
	

}
