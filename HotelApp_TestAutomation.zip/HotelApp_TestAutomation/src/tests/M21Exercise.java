package tests;

import java.util.regex.Pattern;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class M21Exercise {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    baseUrl = "http://adactin.com/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testM21() throws Exception {
    driver.get(baseUrl + "/HotelApp/");
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("arunika7");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("Hi..There..001");
    driver.findElement(By.id("login")).click();
    new Select(driver.findElement(By.id("location"))).selectByVisibleText("Melbourne");
    new Select(driver.findElement(By.id("room_nos"))).selectByVisibleText("2 - Two");
    new Select(driver.findElement(By.id("adult_room"))).selectByVisibleText("2 - Two");
    driver.findElement(By.id("Submit")).click();
    driver.findElement(By.id("radiobutton_2")).click();
    
    //print out contents
    //get all rows
    List<WebElement> rows = driver.findElement(By.id("select_form")).findElements(By.tagName("tr"));
    //print header row
    for (int i=2;i<11;i++)
    	System.out.print(driver.findElement(By.xpath(".//*[@id='select_form']/table/tbody/tr[2]/td/table/tbody/tr[1]/td["+i+"]")));
    System.out.println();
    
    for(int i=1; i<rows.size()-3;i++) {
    	System.out.print(driver.findElement(By.id("hotel_name_"+i)).getAttribute("value")+"\t");
    	System.out.print(driver.findElement(By.id("location_"+i)).getAttribute("value")+"\t");
    	System.out.print(driver.findElement(By.id("rooms_"+i)).getAttribute("value")+"\t");
    	System.out.print(driver.findElement(By.id("arr_date_"+i)).getAttribute("value")+"\t");
    	System.out.print(driver.findElement(By.id("dep_date_"+i)).getAttribute("value")+"\t");
    	System.out.print(driver.findElement(By.id("no_days_"+i)).getAttribute("value")+"\t");
    	System.out.print(driver.findElement(By.id("room_type_"+i)).getAttribute("value")+"\t");
    	System.out.print(driver.findElement(By.id("price_night_"+i)).getAttribute("value")+"\t");
    	System.out.print(driver.findElement(By.id("total_price_"+i)).getAttribute("value")+"\t");
    	System.out.println();
    }
    
    driver.findElement(By.id("continue")).click();
    driver.findElement(By.id("first_name")).clear();
    driver.findElement(By.id("first_name")).sendKeys("Arunika");
    driver.findElement(By.id("last_name")).clear();
    driver.findElement(By.id("last_name")).sendKeys("Oyshi");
    driver.findElement(By.id("address")).clear();
    driver.findElement(By.id("address")).sendKeys("123 Anywhere Ln, 76010");
    driver.findElement(By.id("cc_num")).clear();
    driver.findElement(By.id("cc_num")).sendKeys("1000969278000000");
    new Select(driver.findElement(By.id("cc_type"))).selectByVisibleText("American Express");
    new Select(driver.findElement(By.id("cc_exp_month"))).selectByVisibleText("December");
    new Select(driver.findElement(By.id("cc_exp_year"))).selectByVisibleText("2018");
    driver.findElement(By.id("cc_cvv")).clear();
    driver.findElement(By.id("cc_cvv")).sendKeys("9278");
    driver.findElement(By.id("book_now")).click();
    driver.findElement(By.linkText("Logout")).click();
    driver.findElement(By.linkText("Click here to login again")).click();
    driver.findElement(By.id("username")).clear();
    driver.findElement(By.id("username")).sendKeys("arunika7");
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("Hi..There..001");
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
