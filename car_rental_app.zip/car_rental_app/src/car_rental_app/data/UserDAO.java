package car_rental_app.data;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import car_rental_app.model.User;
import car_rental_app.util.SQLConnection;

public class UserDAO {

	static SQLConnection DBMgr = SQLConnection.getInstance();
	
	public static ArrayList<String> getAllRevokedUsers() {
		Statement stmt = null;    
		Connection conn = null;
		ArrayList<String> revokeList = new ArrayList<String>();
		try {   
			conn = SQLConnection.getDBConnection();  
			stmt = conn.createStatement();
			String searchUsername = " SELECT username from USER WHERE isrevoked=1 order by username";
			ResultSet userList = stmt.executeQuery(searchUsername);
			while(userList.next()) {
				String username = userList.getString("username");
				revokeList.add(username);
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try { 
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		return revokeList;
	}
	
	public static void registerUser(User user) {
		Statement stmt = null;   
		Connection conn = SQLConnection.getDBConnection();  
		String registerUser = "INSERT INTO USER (utaid,username,first_name,last_name,password,email,aacmembership,role,isrevoked,age) ";					
		registerUser += " VALUES ('"  
				+ user.getUtaId() + "','"
				+ user.getUsername() + "','"		
				+ user.getFirstName() + "','"
				+ user.getLastName() + "','" 
				+ user.getPassword()  + "','"
				+ user.getEmail() + "',"
				+ user.getAacMembership() + ",'"		
				+ user.getRole() + "',"
				+ user.getIsRevoked() + "," 
				+ user.getAge() + ")" ;
		try {   
		conn = SQLConnection.getDBConnection();  
		conn.setAutoCommit(false);   
		stmt = conn.createStatement();
		stmt.executeUpdate(registerUser);
		conn.commit();					 
	} catch (SQLException sqle) { 
		sqle.printStackTrace();
	} finally {
		try {
			conn.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		};
	}
	} 
	
	//update a user for edit profile
	public static void updateUser(User user) {
		Statement stmt = null;   
		Connection conn = SQLConnection.getDBConnection();  
		String updateUser = "UPDATE USER SET age="+user.getAge()+",utaid='"+user.getUtaId()
		+"',first_name='"+user.getFirstName()+"',last_name='"+user.getLastName()+"',password='"
				+user.getPassword()+"',email='"+user.getEmail()+"',aacmembership="
		+user.getAacMembership()+",isRevoked="+user.getIsRevoked()+" ";		
		updateUser += " WHERE USERNAME='"+user.getUsername()+"'";
		try {   
		conn = SQLConnection.getDBConnection();  
		conn.setAutoCommit(false);   
		stmt = conn.createStatement();
		stmt.executeUpdate(updateUser);
		conn.commit();					 
	} catch (SQLException sqle) { 
		sqle.printStackTrace();
	} finally {
		try {
			conn.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		};
	}
	}
	
	//get a user based on username (needed for login)
	public static User getUser(String username) {
		Statement stmt = null;   
		Connection conn = null;  
		User user = new User();
		try {   
			conn = SQLConnection.getDBConnection();  
			stmt = conn.createStatement();
			String searchUsername = " SELECT * from USER WHERE USERNAME = '"+username+"'";
			ResultSet userList = stmt.executeQuery(searchUsername);
			while(userList.next()) {
				int id = userList.getInt("id");
				String utaId = userList.getString("utaid");
				String firstName  = userList.getString("first_name");
				String lastName  = userList.getString("last_name");
				String password = userList.getString("password");
				String email  = userList.getString("email");
				int aacMembership  = userList.getInt("aacmembership");
				String role  = userList.getString("role");
				int isRevoked = userList.getInt("isrevoked");
				int age  = userList.getInt("age");
				
				//set User
				user.setId(id);
				user.setFirstName(firstName);
				user.setLastName(lastName);
				user.setUsername(username);
				user.setPassword(password);
				user.setEmail(email);
				user.setUtaId(utaId);
				user.setAge(age);
				user.setAacMembership(aacMembership);
				user.setRole(role);
				user.setIsRevoked(isRevoked); 		
				user.setAgeAsString(Integer.toString(age));
				
			}
			
			} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		return user;
	}
	
	
	//check if a username already exists in DB or not
	public static boolean uniqueUsername(String username) {  
		Statement stmt = null;   
		Connection conn = null;  
		try {   
			conn = SQLConnection.getDBConnection();  
			stmt = conn.createStatement();
			String searchUsername = " SELECT * from USER WHERE USERNAME = '"+username+"'";
			ResultSet userList = stmt.executeQuery(searchUsername);
			ArrayList<User> userListInDB = new ArrayList<User>();
			while (userList.next()) {
				User user = new User(); 
				userListInDB.add(user);	 
			} 
			return (userListInDB.isEmpty());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		return false;
	}
	
	public static void deleteUser(String username) {
		Statement stmt = null;   
		Connection conn = null;  
		try {   
			conn = SQLConnection.getDBConnection();  
			stmt = conn.createStatement();
			String delete = " DELETE from USER WHERE username = '"+username+"' LIMIT 1 ";
			stmt.executeUpdate(delete);
			conn.commit();			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		}
		
}