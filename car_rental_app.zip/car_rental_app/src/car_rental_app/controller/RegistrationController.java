package car_rental_app.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import car_rental_app.data.UserDAO;
import car_rental_app.model.*;

@WebServlet("/RegistrationController")
public class RegistrationController extends HttpServlet {

	private static final long serialVersionUID = 3L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response); 
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();	
		String action = request.getParameter("action");
		String url = "/register.jsp";
		
		if(action.equalsIgnoreCase("register"))
		{
			
			User user = new User();
			
			//set user attributes
			user.setFirstName(request.getParameter("firstName"));
			user.setLastName(request.getParameter("lastName"));
			user.setUsername(request.getParameter("username"));
			user.setPassword(request.getParameter("password"));
			user.setEmail(request.getParameter("email"));
			user.setUtaId(request.getParameter("utaId"));
			user.setAgeAsString(request.getParameter("age")); 
			user.setAacMembership(Integer.parseInt(request.getParameter("aac"))); //safe, aacMem is strictly 0/1 from jsp form radio buttons
			user.setRole(request.getParameter("role"));
			user.setIsRevoked(0); //default for newly registered user is unrevoked
			
			UserErrorMsgs UerrorMsgs = new UserErrorMsgs();
			user.validateUser(user, UerrorMsgs, action);
			session.setAttribute("User",user);
			session.setAttribute("errorMsgs",UerrorMsgs);
			if (UerrorMsgs.getErrorMsg().equals("")) {
				UserDAO.registerUser(user); //save employee if no errors
				session.removeAttribute("User");
				session.removeAttribute("errorMsgs");
				url = "/login.jsp"; //if successful, redirect to login page
			}				
			
		}		
		
		else if(action.equalsIgnoreCase("goHome")) {
			session.removeAttribute("User");
			session.removeAttribute("errorMsgs");
			url="/login.jsp";
		}
		else // redirect all other posts to get
			doGet(request,response);

		getServletContext().getRequestDispatcher(url).forward(request, response);
			
	}
}