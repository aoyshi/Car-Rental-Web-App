package car_rental_app.model;
import java.io.Serializable;
import car_rental_app.data.CarDAO;

public class Car implements Serializable {
	private static final long serialVersionUID = 2L;
	private int id;
	private String name;
	private int capacity;
	private double weekdayRate;
	private double weekendRate;
	private double weeklyRate;
	private double dailyGps;
	private double dailyOnstar;
	private double dailySirius;
	//user-inputted numbers in add-new-car form
	private String capacityAsString;
	private String weekdayRateAsString;
	private String weekendRateAsString;
	private String weeklyRateAsString;
	private String dailyGpsAsString;
	private String dailyOnstarAsString;
	private String dailySiriusAsString;

	public int getId() { return id; }
	public void setId(int id) { this.id=id; }
	
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }

	public int getCapacity() { return capacity; }
	public void setCapacity(int capacity) { this.capacity = capacity; }

	public double getWeekdayRate() {return weekdayRate;}
	public void setWeekdayRate(double weekdayRate) {this.weekdayRate = weekdayRate;}

	public double getWeekendRate() {return weekendRate;}
	public void setWeekendRate(double weekendRate) {this.weekendRate = weekendRate;}

	public double getWeeklyRate() {return weeklyRate;}
	public void setWeeklyRate(double weeklyRate) {this.weeklyRate = weeklyRate;}

	public double getDailyGps() {return dailyGps;}
	public void setDailyGps(double dailyGps) {this.dailyGps = dailyGps;}

	public double getDailyOnstar() {return dailyOnstar;}
	public void setDailyOnstar(double dailyOnstar) {this.dailyOnstar = dailyOnstar;}

	/*as string*/
	public double getDailySirius() {return dailySirius;}
	public void setDailySirius(double dailySirius) {this.dailySirius = dailySirius;}

	public String getCapacityAsString() {return capacityAsString;}
	public void setCapacityAsString(String capacityAsString) {this.capacityAsString=capacityAsString;}
	
	public String getWeekdayRateAsString() {return weekdayRateAsString;}
	public void setWeekdayRateAsString(String weekdayRateAsString) {this.weekdayRateAsString=weekdayRateAsString;}
	
	public String getWeekendRateAsString() {return weekendRateAsString;}
	public void setWeekendRateAsString(String weekendRateAsString) {this.weekendRateAsString=weekendRateAsString;}

	public String getWeeklyRateAsString() {return weeklyRateAsString;}
	public void setWeeklyRateAsString(String weeklyRateAsString) {this.weeklyRateAsString=weeklyRateAsString;}
	
	public String getDailyGpsAsString() {return dailyGpsAsString;}
	public void setDailyGpsAsString(String dailyGpsAsString) {this.dailyGpsAsString=dailyGpsAsString;}

	public String getDailyOnstarAsString() {return dailyOnstarAsString;}
	public void setDailyOnstarAsString(String dailyOnstarAsString) {this.dailyOnstarAsString=dailyOnstarAsString;}
	
	public String getDailySiriusAsString() {return dailySiriusAsString;}
	public void setDailySiriusAsString(String dailySiriusAsString) {this.dailySiriusAsString=dailySiriusAsString;}

	/************ VALIDATIONS *************/	
	public void validateCar(Car car, CarErrorMsgs errorMsgs) {	
		errorMsgs.setNameError(validateName(car.getName()));
		errorMsgs.setWeekdayRateError(validateWeekdayRate(car.getWeekdayRateAsString()));
		errorMsgs.setWeekendRateError(validateWeekendRate(car.getWeekendRateAsString()));
		errorMsgs.setWeeklyRateError(validateWeeklyRate(car.getWeeklyRateAsString()));
		errorMsgs.setDailyGpsError(validateGpsRate(car.getDailyGpsAsString()));
		errorMsgs.setDailyOnstarError(validateOnstarRate(car.getDailyOnstarAsString()));
		errorMsgs.setDailySiriusError(validateSiriusRate(car.getDailySiriusAsString()));
		validateCapacity(car,errorMsgs);
	}	
	public void validateCapacity(Car car, CarErrorMsgs errorMsgs) {		
		errorMsgs.setCapacityError(validateCapacity(car.getCapacityAsString()));
		errorMsgs.setErrorMsg();
	}	
	private String validateName (String name) {
		name = name.trim(); 
		String result="";
		if (!stringSize(name,2,50))
			result= "Car Name must between 2 and 50 characters";
		else
			if (!name.matches("^[a-zA-Z0-9]+$"))
				result="Car Name must only contain alphabets and numbers";
			else
				if (!CarDAO.uniqueCarName(name))
					result="This car name already in database";
		return result;	
	}		
	private String validateCapacity(String capacityAsString) {
		String result = "";
		if(!isTextAnInteger(capacityAsString))
			result="Car Capacity must be a whole number";
		else {
			this.setCapacity(Integer.parseInt(capacityAsString));		
			if (capacity < 1 || capacity > 30)
				result="Car Capacity must be between 1 and 30";
		}		
		return result;	
	}	
	private String validateWeekdayRate(String weekdayRateAsString) {
        String result="";		
		if(!isTextADouble(weekdayRateAsString))
			result= "Weekday Rate must be a number";	
		else {
		    this.setWeekdayRate(Double.parseDouble(weekdayRateAsString));			
			if (weekdayRate < 0.01)
				result= "Weekday Rate cannot be less than $0.01";
			else
				if(weekdayRate > 5000.00) 
					result= "Weekday Rate cannot be greater than $5000.00";
		}				
		return result;
	}	
	private String validateWeekendRate(String weekendRateAsString) {
        String result="";		
		if(!isTextADouble(weekendRateAsString))
			result= "Weekend Rate must be a number";	
		else {
		    this.setWeekendRate(Double.parseDouble(weekendRateAsString));			
			if (weekendRate < 0.01)
				result= "Weekend Rate cannot be less than $0.01";
			else
				if(weekendRate > 5000.00) 
					result= "Weekend Rate cannot be greater than $5000.00";
		}				
		return result;
	}	
	private String validateWeeklyRate(String weeklyRateAsString) {
        String result="";		
		if(!isTextADouble(weeklyRateAsString))
			result= "Weekly Rate must be a number";	
		else {
			this.setWeeklyRate(Double.parseDouble(weeklyRateAsString));						
			if (weeklyRate < 0.01)
				result= "Weekly Rate cannot be less than $0.01";
			else
				if(weeklyRate > 5000.00) 
					result= "Weekly Rate cannot be greater than $5000.00";
		}				
		return result;
	}	
	private String validateGpsRate(String dailyGpsAsString) {
		String result="";		
		if(!isTextADouble(dailyGpsAsString))
			result= "GPS Rate must be a number";
		
		else {
			this.setDailyGps(Double.parseDouble(dailyGpsAsString));				
			if (dailyGps < 0.01)
				result= "GPS Rate cannot be less than $0.01";
			else
				if(dailyGps > 5000.00) 
					result= "GPS Rate cannot be greater than $5000.00";
		}				
		return result;
	}
	private String validateSiriusRate(String dailySiriusAsString) {
		String result="";		
		if(!isTextADouble(dailySiriusAsString))
			result= "SiriusXM Rate must be a number";	
		else {
		    this.setDailySirius(Double.parseDouble(dailySiriusAsString));			
			if (dailySirius < 0.01)
				result= "SiriusXM Rate cannot be less than $0.01";
			else
				if(dailySirius > 5000.00) 
					result= "SiriusXM Rate cannot be greater than $5000.00";
		}				
		return result;
	}
	private String validateOnstarRate(String dailyOnstarAsString) {
		String result="";		
		if(!isTextADouble(dailyOnstarAsString))
			result= "OnStar Rate must be a number";	
		else {
			this.setDailyOnstar(Double.parseDouble(dailyOnstarAsString));
			if (dailyOnstar < 0.01)
				result= "OnStar Rate cannot be less than $0.01";
			else
				if(dailyOnstar > 5000.00) 
					result= "OnStar Rate cannot be greater than $5000.00";
		}				
		return result;
	}	
   /************* AUXILIARY FUNCTIONS *************/	
	private boolean stringSize(String string, int min, int max) {
		return string.length()>=min && string.length()<=max;
	}
	private boolean isTextAnInteger (String string) {
        boolean result;
		try {
            Long.parseLong(string);
            result=true;
        } 
        catch (NumberFormatException e) {
            result=false;
        }
		return result;
	}	
	private boolean isTextADouble(String string) {
        boolean result;
		try {
            Double.parseDouble(string);
            result=true;
        } 
        catch (NumberFormatException e)  {
            result=false;
        }
		return result;
	}
}
