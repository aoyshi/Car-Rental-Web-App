package car_rental_app.selenium;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;

import car_rental_app.data.CarDAO;
import car_rental_app.data.UserDAO;
import car_rental_app.functions.App_BusinessFunctions;
import car_rental_app.model.User;

import java.util.Properties;
import java.io.FileInputStream;

public class SeleniumTC13 extends App_BusinessFunctions {
	
  private StringBuffer verificationErrors = new StringBuffer();
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
    //MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));
    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));
  }

  @Test
  public void seleniumTC13() throws Exception {
	    driver.get(sAppURL);
	    //Login as a valid user
	    App_BF_Login(driver,"customer","Hi..There..001");
	    //Click on edit my profile link from homepage
	    driver.findElement(By.linkText(prop.getProperty("Lnk_Home_EditProfile"))).click();
	    //get user from DB for expected results
	    User user = UserDAO.getUser("customer");
	    //Compare expected and actual outputs in profile form fields 
	    assertEquals(user.getFirstName(), driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_First_Name"))).getAttribute("value"));
	    assertEquals(user.getLastName(), driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Last_Name"))).getAttribute("value"));
	    assertEquals(user.getUtaId(), driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_UTA_ID"))).getAttribute("value"));
	    assertEquals(user.getUsername(), driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Username"))).getAttribute("value"));
	    assertEquals(user.getPassword(), driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Password"))).getAttribute("value"));
	    assertEquals(user.getEmail(), driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Email"))).getAttribute("value"));
	    assertEquals(user.getRole(),driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Role"))).getAttribute("value"));
	    assertEquals(Integer.toString(user.getAge()), driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Age"))).getAttribute("value"));
	    //check aac membership radio button
	    if(user.getAacMembership()==1)
	       assertEquals(Integer.toString(user.getAacMembership()), driver.findElement(By.id(prop.getProperty("Rad_Edit_Own_Profile_AAC_Yes"))).getAttribute("value"));
	    else
		   assertEquals(Integer.toString(user.getAacMembership()), driver.findElement(By.id(prop.getProperty("Rad_Edit_Own_Profile_AAC_No"))).getAttribute("value"));
	    //Click back to homepage link
	    driver.findElement(By.linkText(prop.getProperty("Lnk_Edit_Own_Profile_Back_Home"))).click();
	    //Click on edit my profile link from homepage
	    driver.findElement(By.linkText(prop.getProperty("Lnk_Home_EditProfile"))).click();
	    //click cancel button
	    driver.findElement(By.name(prop.getProperty("Btn_Edit_Own_Profile_Cancel"))).click();
	    //Click logout from homepage
	    driver.findElement(By.linkText(prop.getProperty("Lnk_Home_Logout"))).click();   
  }
  
  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}
