package car_rental_app.selenium;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;

import car_rental_app.data.CarDAO;
import car_rental_app.functions.App_BusinessFunctions;

import java.util.Properties;
import java.io.FileInputStream;

public class SeleniumTC22 extends App_BusinessFunctions {
	
  private StringBuffer verificationErrors = new StringBuffer();
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
    //MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));
    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));
  }

  @Test
  public void seleniumTC22() throws Exception {
    driver.get(sAppURL);
    //Login as manager
    App_BF_Login(driver,"manager","Hi..There..001");
    //Click Add New Car link
    driver.findElement(By.linkText(prop.getProperty("Lnk_ManagerHome_AddCars"))).click();
    //Add Car with errors
    App_BF_Add_New_Car(driver,"","","","","","","","");
    //Compare error messages expected and actual  
    assertEquals("Please correct the following errors", driver.findElement(By.name(prop.getProperty("Lbl_Add_Car_Form_Error"))).getAttribute("value"));
    assertEquals("Car Name must between 2 and 50 characters", driver.findElement(By.name(prop.getProperty("Lbl_Add_Car_Name_Error"))).getAttribute("value"));
    assertEquals("Car Capacity must be a whole number", driver.findElement(By.name(prop.getProperty("Lbl_Add_Car_Capacity_Error"))).getAttribute("value"));
    assertEquals("Weekday Rate must be a number", driver.findElement(By.name(prop.getProperty("Lbl_Add_Car_Weekday_Rate_Error"))).getAttribute("value"));
    assertEquals("Weekend Rate must be a number", driver.findElement(By.name(prop.getProperty("Lbl_Add_Car_Weekend_Rate_Error"))).getAttribute("value"));
    assertEquals("Weekly Rate must be a number", driver.findElement(By.name(prop.getProperty("Lbl_Add_Car_Weekly_Rate_Error"))).getAttribute("value"));
    assertEquals("GPS Rate must be a number", driver.findElement(By.name(prop.getProperty("Lbl_Add_Car_Daily_Gps_Error"))).getAttribute("value"));
    assertEquals("OnStar Rate must be a number", driver.findElement(By.name(prop.getProperty("Lbl_Add_Car_Daily_Onstar_Error"))).getAttribute("value"));
    assertEquals("SiriusXM Rate must be a number", driver.findElement(By.name(prop.getProperty("Lbl_Add_Car_Daily_Sirius_Error"))).getAttribute("value"));
    //Add a valid car to clear error msgs
    App_BF_Add_New_Car(driver,"TestCar","1","100.00","100.00","700.00","10.00","10.00","10.00");
    //Click logout from add new car page
    driver.findElement(By.linkText(prop.getProperty("Lnk_Add_Car_Logout"))).click();
  }
  
  @After
  public void tearDown() throws Exception {
	CarDAO.deleteCar("TestCar"); //delete test car from DB for next test
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}
