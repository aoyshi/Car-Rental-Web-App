/**View My Reservations : Start or End Times cannot be blank**/

package car_rental_app.selenium;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import car_rental_app.functions.App_BusinessFunctions;

public class SeleniumTC40 extends App_BusinessFunctions {
	
  private StringBuffer verificationErrors = new StringBuffer();
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
    //MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));

    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));

  }

  @Test
  public void seleniumTC_ViewUserReservations_3() throws Exception {
    driver.get(sAppURL);
    //login with correct creds
    App_BF_Login(driver,"customer","Hi..There..001");
    //Travel to View all Cars Page
    driver.findElement(By.linkText(prop.getProperty("Lnk_CustomerHome_ViewMyRR"))).click();    
    //check Title of Page
    assertEquals("View My Reservations", driver.getTitle());
    //Check Table Sanity
    App_BF_ViewUserReservations_Filter(driver,"","","customer");
	//Check if error messages are set properly
	assertEquals("Please correct the following errors", driver.findElement(By.name(prop.getProperty("Lbl_View_My_Reservations_Form_Error"))).getAttribute("value"));
	assertEquals("Start Date-Time cannot be blank", driver.findElement(By.name(prop.getProperty("Lbl_View_My_Reservations_Start_Error"))).getAttribute("value"));
	assertEquals("End Date-Time cannot be blank", driver.findElement(By.name(prop.getProperty("Lbl_View_My_Reservations_End_Error"))).getAttribute("value"));
    //clear button
	driver.findElement(By.name(prop.getProperty("Btn_View_My_Reservations_Clear"))).click();
	//logout
    App_BF_Logout(driver);
  }
  
  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}
