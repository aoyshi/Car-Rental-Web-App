package car_rental_app.selenium;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;

import car_rental_app.data.CarDAO;
import car_rental_app.data.UserDAO;
import car_rental_app.functions.App_BusinessFunctions;
import car_rental_app.model.User;

import java.util.Properties;
import java.io.FileInputStream;

public class SeleniumTC11 extends App_BusinessFunctions {
	
  private StringBuffer verificationErrors = new StringBuffer();
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
    //MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));
    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));
  }

  @Test
  public void seleniumTC10() throws Exception {
	    driver.get(sAppURL);
	    //Login as admin
	    App_BF_Login(driver,"admin","Hi..There..001");
	    //Click revoke a renter link from homepage
	    driver.findElement(By.linkText(prop.getProperty("Lnk_AdminHome_Revoke"))).click();
	    //Enter username and click revoke
	    App_BF_Revoke_Renter(driver,"");
	    //Compare expected and actual error messages
	    assertEquals("Please correct the following errors", driver.findElement(By.name(prop.getProperty("Lbl_Revoke_Form_Error"))).getAttribute("value"));
	    assertEquals("Username cannot be blank", driver.findElement(By.name(prop.getProperty("Lbl_Revoke_Username_Error"))).getAttribute("value"));	    
	    //check web page items
	    assertEquals("*List sorted based on alphabetical order of username (A to Z)", driver.findElement(By.xpath(prop.getProperty("Lbl_Revoke_Sort_Order"))).getText());	    
	    assertEquals("Revoked Renters", driver.findElement(By.xpath(prop.getProperty("Lbl_Revoke_Table_Title"))).getText());	    
	    assertEquals("arevokee", driver.findElement(By.xpath(prop.getProperty("Lbl_Revoke_Table_First_Item"))).getText());	    	    
	    //revoke valid user to clear error msgs and verify table input
	    App_BF_Revoke_Renter(driver,"customer");
	    assertEquals("customer", driver.findElement(By.xpath(prop.getProperty("Lbl_Revoke_Table_Second_Item"))).getText());	    	    
	    //Click logout from add new car page
	    driver.findElement(By.linkText(prop.getProperty("Lnk_Revoke_Logout"))).click();
  }
  
  @After
  public void tearDown() throws Exception {
	//unrevoke the test user for next test
	User testUser = UserDAO.getUser("customer");
	testUser.setIsRevoked(0);
	UserDAO.updateUser(testUser);
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}
