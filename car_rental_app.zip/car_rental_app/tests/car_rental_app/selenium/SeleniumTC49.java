/**Request Rental : CheckOut Date-Time Saturday Error, Return Date-Time Saturday Error**/

package car_rental_app.selenium;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;

import car_rental_app.functions.App_BusinessFunctions;

import java.util.Properties;
import java.io.FileInputStream;

public class SeleniumTC49 extends App_BusinessFunctions {
	
  private StringBuffer verificationErrors = new StringBuffer();
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
    //MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));

    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));

  }

  @Test
  public void seleniumTC_RequestRental_5() throws Exception {
    driver.get(sAppURL);
    //login with correct creds
    App_BF_Login(driver,"customer","Hi..There..001");
    //Travel to View all Cars Page
    driver.findElement(By.linkText(prop.getProperty("Lnk_CustomerHome_RequestRental"))).click();    
    //check Title of Page
    assertEquals("Request Rental", driver.getTitle());
    //Check Table Sanity
    App_BF_RequestRental_Filter(driver,"2019-01-12 07:00","2019-01-19 07:00","2");
	//Check if error messages are set properly
    
	assertEquals("Please correct the following errors", driver.findElement(By.name(prop.getProperty("Lbl_Request_Rental_Form_Error"))).getAttribute("value"));
	assertEquals("CheckOut Time must be between 08:00 to 17:00 on Saturdays", driver.findElement(By.name(prop.getProperty("Lbl_Request_Rental_Start_Error"))).getAttribute("value"));
	assertEquals("Return Time must be between 08:00 to 17:00 on Saturdays", driver.findElement(By.name(prop.getProperty("Lbl_Request_Rental_End_Error"))).getAttribute("value"));
	assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Request_Rental_Capacity_Error"))).getAttribute("value"));
	//press clear button
		driver.findElement(By.name(prop.getProperty("Btn_Request_Rental_Clear"))).click();
	
	//logout
    App_BF_Logout(driver);
  }
  
  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}
