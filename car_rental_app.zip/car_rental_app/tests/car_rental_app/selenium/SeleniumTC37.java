/**Manager Delete Reservation : No Error**/

package car_rental_app.selenium;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;

import car_rental_app.functions.App_BusinessFunctions;

import java.util.Properties;
import java.io.FileInputStream;

public class SeleniumTC37 extends App_BusinessFunctions {
	
  private StringBuffer verificationErrors = new StringBuffer();
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
    //MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));

    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));
 
  }

  @Test
  public void seleniumTC_ViewReservationDetails_1() throws Exception {
    driver.get(sAppURL);
    //login with correct creds
    App_BF_Login(driver,"manager","Hi..There..001");
    //Travel to View all Cars Page
    driver.findElement(By.linkText(prop.getProperty("Lnk_ManagerHome_ViewAllRR"))).click();    
    
    //check Title of Page
    assertEquals("View All Reservations", driver.getTitle());
    //Check Table Sanity BEFORE delete
    App_BF_ViewAllReservations(driver);
    
    //delete first reservation in list
    driver.findElement(By.linkText(prop.getProperty("Lnk_View_All_Reservations_Delete"))).click();    
    
    //Check Table Sanity AFTER delete
    App_BF_ViewAllReservations(driver);
        
    //Back To Homepage
  	App_BF_Homepage(driver);
    //logout
    App_BF_Logout(driver);

  }
  
  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}
