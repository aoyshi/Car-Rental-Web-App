/**View Reservation Details : No Error**/

package car_rental_app.selenium;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import car_rental_app.functions.App_BusinessFunctions;
import car_rental_app.model.ReservationDetails;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.io.FileInputStream;

public class SeleniumTC35 extends App_BusinessFunctions {
	
  private StringBuffer verificationErrors = new StringBuffer();
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
    //MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));

    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));
 
  }

  @Test
  public void seleniumTC_ViewReservationDetails_2() throws Exception {
	driver.get(sAppURL);
    //login with correct creds
    App_BF_Login(driver,"manager","Hi..There..001");
    //Travel to View all Cars Page
    driver.findElement(By.linkText(prop.getProperty("Lnk_ManagerHome_ViewAllRR"))).click();    
    //Check Table Sanity
    driver.findElement(By.name(prop.getProperty("Txt_View_All_Reservations_Start"))).clear();
	driver.findElement(By.name(prop.getProperty("Txt_View_All_Reservations_Start"))).sendKeys("2018-09-01 12:00");
	driver.findElement(By.name(prop.getProperty("Txt_View_All_Reservations_End"))).clear();
	driver.findElement(By.name(prop.getProperty("Txt_View_All_Reservations_End"))).sendKeys("2018-12-31 12:00");
	driver.findElement(By.name(prop.getProperty("Btn_View_All_Reservations_Filter"))).click();
	  
	driver.findElement(By.xpath(prop.getProperty("Lnk_View_All_Reservations_View"))).click();
	
	  List<WebElement> table_contents= new ArrayList<>();
	  ArrayList<ReservationDetails> allReservations = new ArrayList();
	  //Check Title of Page
	  assertEquals("View Reservation Details",driver.getTitle());
	  //Check if Correct details are carried to the details page
	  //Check if data is same as DB
	  Iterator iter = allReservations.iterator();
	  while(iter.hasNext())
	  {
		    ReservationDetails rsdet = (ReservationDetails)iter.next();
		    int resID = Integer.parseInt(driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[8]/td[2]")).getText());
		    if(rsdet.getId()==resID)
		    {  
			  assertEquals(rsdet.getUsername(), driver.findElement(By.xpath(prop.getProperty("Lbl_View_Res_Details_Username"))).getText());
			  assertEquals(rsdet.getCarName(), driver.findElement(By.xpath(prop.getProperty("Lbl_View_Res_Details_Car_Name"))).getText());
			  assertEquals(rsdet.getCapacity(), driver.findElement(By.xpath(prop.getProperty("Lbl_View_Res_Details_Capacity"))).getText());
			  assertEquals(rsdet.getStartTime(), driver.findElement(By.xpath(prop.getProperty("Lbl_View_Res_Details_CheckOut"))).getText());
			  assertEquals(rsdet.getEndTime(), driver.findElement(By.xpath(prop.getProperty("Lbl_View_Res_Details_Return"))).getText());
			  assertEquals(rsdet.getTotalPrice(), driver.findElement(By.xpath(prop.getProperty("Lbl_View_Res_Details_Price"))).getText());
			  assertEquals(rsdet.getAdditionalFeatures(), driver.findElement(By.xpath(prop.getProperty("Lbl_View_Res_Details_Extras"))).getText());
			  assertEquals(rsdet.getId(), driver.findElement(By.xpath(prop.getProperty("Lbl_View_Res_Details_ID"))).getText());
		    }
	  }
	  //logout
	  App_BF_Logout(driver);
	
	  }
	  
	  @After
	  public void tearDown() throws Exception {
	    driver.quit();
	    String verificationErrorString = verificationErrors.toString();
	    if (!"".equals(verificationErrorString)) {
	      fail(verificationErrorString);
	    }
	  }

}
