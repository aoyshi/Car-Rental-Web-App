/**Pay For Rental with errors***/

package car_rental_app.selenium;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;

import car_rental_app.functions.App_BusinessFunctions;

import java.util.Properties;
import java.io.FileInputStream;

public class SeleniumTC53 extends App_BusinessFunctions {
	
  private StringBuffer verificationErrors = new StringBuffer();
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
    //MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));

    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));

  }

  @Test
  public void seleniumTC_Payment_3() throws Exception {
    driver.get(sAppURL);
    //login with correct creds
    App_BF_Login(driver,"customer","Hi..There..001");
    //Travel to View all Cars Page
    driver.findElement(By.linkText(prop.getProperty("Lnk_CustomerHome_RequestRental"))).click();    
    //check Title of Page
    assertEquals("Request Rental", driver.getTitle());
    //Check Table Sanity
    App_BF_RequestRental_Filter(driver,"2022-03-10 12:00","2022-03-15 12:00","3");
    driver.findElement(By.xpath(prop.getProperty("Lnk_Request_Rental_Reserve"))).click();
    App_BF_AddFeatures(driver,true, true, true, true);
    App_BF_Payment(driver, "12312 abc", "abcderhjkpinshq1", "2019", "abc");

    assertEquals("Please correct the following errors", driver.findElement(By.name(prop.getProperty("Lbl_Payment_Form_Error"))).getAttribute("value"));
	assertEquals("Your name must only contain alphabets and spaces", driver.findElement(By.name(prop.getProperty("Lbl_Payment_Name_On_Card_Error"))).getAttribute("value"));
	assertEquals("Your Card Number must be a number", driver.findElement(By.name(prop.getProperty("Lbl_Payment_Card_Number_Error"))).getAttribute("value"));
	assertEquals("Invalid Entry : Card Number must be in the format yyyy-MM", driver.findElement(By.name(prop.getProperty("Lbl_Payment_Card_Expires_Error"))).getAttribute("value"));
	assertEquals("Your Card Security Code must be a number", driver.findElement(By.name(prop.getProperty("Lbl_Payment_CCV_Error"))).getAttribute("value"));
    
	App_BF_Payment(driver, "Jane Doe", "4321568745679032", "2018-12", "657");	
	App_BF_Logout(driver);
  }
  
  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}
