package car_rental_app.selenium;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;

import car_rental_app.data.UserDAO;
import car_rental_app.functions.App_BusinessFunctions;

import java.util.Properties;
import java.io.FileInputStream;

public class SeleniumTC09 extends App_BusinessFunctions {
	
  private StringBuffer verificationErrors = new StringBuffer();
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
    //MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));

    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));

  }

  @Test
  public void seleniumTC09() throws Exception {
    driver.get(sAppURL);
    //Click register button from login page
    driver.findElement(By.id(prop.getProperty("Btn_Login_Register"))).click();    
    //test back home button
    driver.findElement(By.linkText(prop.getProperty("Lnk_Register_Back_Home"))).click();
    //Click register button from login page
    driver.findElement(By.id(prop.getProperty("Btn_Login_Register"))).click(); 
    
    //Enter following data and submit
    App_BF_Register(driver,"John","Smith","1122334455","customer","Passwd.1","mymy@uta.edu","131","no","Admin");
    //Compare error messages expected and actual
    assertEquals("Please correct the following errors", driver.findElement(By.name(prop.getProperty("Lbl_Register_Form_Error"))).getAttribute("value"));
    assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Register_First_Name_Error"))).getAttribute("value"));
    assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Register_Last_Name_Error"))).getAttribute("value"));    
    assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Register_UTA_ID_Error"))).getAttribute("value"));
    assertEquals("Username already exists in database", driver.findElement(By.name(prop.getProperty("Lbl_Register_Username_Error"))).getAttribute("value"));
    assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Register_Password_Error"))).getAttribute("value"));    
    assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Register_Email_Error"))).getAttribute("value"));    
    assertEquals("Your age cannot be greater than 130 years", driver.findElement(By.name(prop.getProperty("Lbl_Register_Age_Error"))).getAttribute("value"));    
    //Register with a valid set of data to clear the error messages and redirect to Login page
    App_BF_Register(driver,"Selenium","Tester","1098765432","testUser","Passwd.1","selenium@test.edu","25","no","Admin");
    //Login using the newly registered credentials
    App_BF_Login(driver, "testUser", "Passwd.1");
    //check header value for successful login
    assertEquals("Welcome Admin : Selenium Tester", driver.findElement(By.id(prop.getProperty("Lbl_Home_Welcome_Header"))).getText());    
    //logout
    App_BF_Logout(driver);
  }
  
  @After
  public void tearDown() throws Exception {
	UserDAO.deleteUser("testUser"); //delete test user from DB for next test
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}
