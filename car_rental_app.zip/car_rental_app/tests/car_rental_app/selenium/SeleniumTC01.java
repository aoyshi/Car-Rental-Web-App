package car_rental_app.selenium;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;

import car_rental_app.functions.App_BusinessFunctions;

import java.util.Properties;
import java.io.FileInputStream;

public class SeleniumTC01 extends App_BusinessFunctions {
	
  private StringBuffer verificationErrors = new StringBuffer();
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
    //MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));

    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));

  }

  @Test
  public void seleniumTC01() throws Exception {
    driver.get(sAppURL);
    //login with correct creds
    App_BF_Login(driver,"customer","Hi..There..001");
    //compare expected and actual error messages
    //assertEquals("", driver.findElement(By.id(prop.getProperty("Lbl_Login_Form_Error"))).getAttribute("value"));
    //assertEquals("", driver.findElement(By.id(prop.getProperty("Lbl_Login_Username_Error"))).getAttribute("value"));
    //assertEquals("", driver.findElement(By.id(prop.getProperty("Lbl_Login_Password_Error"))).getAttribute("value"));    
    //check header value for successful login
    assertEquals("Welcome Customer : customer customer", driver.findElement(By.id(prop.getProperty("Lbl_Home_Welcome_Header"))).getText());    
    //logout
    App_BF_Logout(driver);
  }
  
  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}
