
/**Cancel Reservation (Customer): No error**/

package car_rental_app.selenium;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;

import car_rental_app.data.ReservationDAO;

import java.util.Properties;
import java.io.FileInputStream;
import car_rental_app.functions.App_BusinessFunctions;

public class SeleniumTC43 extends App_BusinessFunctions {
	
  private StringBuffer verificationErrors = new StringBuffer();
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
    //MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));

    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));

  }

  @Test
  public void seleniumTC_Cancel_My_Reservation_6() throws Exception {
    driver.get(sAppURL);
    //login with correct creds
    App_BF_Login(driver,"customer","Hi..There..001");
    //Travel to View all Cars Page
    driver.findElement(By.linkText(prop.getProperty("Lnk_CustomerHome_ViewMyRR"))).click();    
    //check Title of Page
    assertEquals("View My Reservations", driver.getTitle());
    //Check Table Sanity before deletion
    App_BF_ViewUserReservations(driver,"customer");    
    if((driver.findElements(By.tagName("tr")).size()) - 4 != 0)
	{
    	//click cancel reservation for very first one
    	driver.findElement(By.xpath(prop.getProperty("Lnk_View_My_Reservations_Cancel_Res"))).click();
	}
    //check table after deletion
    App_BF_ViewUserReservations(driver,"customer");
    //logout
    App_BF_Logout(driver);
  }
  
  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}
