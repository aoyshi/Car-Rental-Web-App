package car_rental_app.selenium;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;

import car_rental_app.data.CarDAO;
import car_rental_app.data.UserDAO;
import car_rental_app.functions.App_BusinessFunctions;
import car_rental_app.model.User;

import java.util.Properties;
import java.io.FileInputStream;

public class SeleniumTC21 extends App_BusinessFunctions {
	
  private StringBuffer verificationErrors = new StringBuffer();
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
    //MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));
    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));
  }

  @Test
  public void seleniumTC21() throws Exception {
	  driver.get(sAppURL);
	 
	  /**********Find profile (no errors)*********/
	  //Login as a valid user
	  App_BF_Login(driver,"admin","Hi..There..001");
	  //Click on edit another profile link
	  driver.findElement(By.linkText(prop.getProperty("Lnk_AdminHome_EditAnother"))).click();
	  //enter valid username to produce profile
	  App_BF_Find_User_Profile(driver, "manager");
	  assertEquals("User Profile : manager", driver.findElement(By.xpath(prop.getProperty("Lbl_Edit_Another_Profile_Header"))).getText());

	  /**********Edit profile (errors III)*********/
	  //Change INVALID data & click save
	  App_BF_Edit_Profile(driver,"manager","manager","2000000000","Hi..There..001","manager@aol.org","131","no");
	  //Compare error messages expected and actual
	  assertEquals("Please correct the following errors", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Another_Profile_Form_Error"))).getAttribute("value"));
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Another_Profile_First_Name_Error"))).getAttribute("value"));
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Another_Profile_Last_Name_Error"))).getAttribute("value"));    
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Another_Profile_UTA_ID_Error"))).getAttribute("value"));
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Another_Profile_Password_Error"))).getAttribute("value"));    
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Another_Profile_Email_Error"))).getAttribute("value"));    
	  assertEquals("Your age cannot be greater than 130 years", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Another_Profile_Age_Error"))).getAttribute("value"));     
	  //compare success msg
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Another_Profile_Success_Msg"))).getAttribute("value"));   
	  

	  //enter VALID set of data
	  App_BF_Edit_Profile(driver,"manager","manager","2000000000","Hi..There..001","manager@gmail.com","35","no");
	  //Compare error messages expected and actual
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Another_Profile_Form_Error"))).getAttribute("value"));
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Another_Profile_First_Name_Error"))).getAttribute("value"));
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Another_Profile_Last_Name_Error"))).getAttribute("value"));    
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Another_Profile_UTA_ID_Error"))).getAttribute("value"));
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Another_Profile_Password_Error"))).getAttribute("value"));    
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Another_Profile_Email_Error"))).getAttribute("value"));    
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Another_Profile_Age_Error"))).getAttribute("value"));     
	  //compare success msg
	  assertEquals("Changes successfully saved.", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Another_Profile_Success_Msg"))).getAttribute("value"));   
	  
	  //Click cancel to go back to homepage
	  driver.findElement(By.name(prop.getProperty("Btn_Edit_Another_Profile_Cancel"))).click();
	  
	  //come back to same profile to check cancel button to go to homepage
	  driver.findElement(By.linkText(prop.getProperty("Lnk_AdminHome_EditAnother"))).click();
	  App_BF_Find_User_Profile(driver, "manager");	  
	  //check values if captured right
	  assertEquals("manager", driver.findElement(By.name(prop.getProperty("Txt_Edit_Another_Profile_First_Name"))).getAttribute("value"));
	  assertEquals("manager", driver.findElement(By.name(prop.getProperty("Txt_Edit_Another_Profile_Last_Name"))).getAttribute("value"));    
	  assertEquals("2000000000", driver.findElement(By.name(prop.getProperty("Txt_Edit_Another_Profile_UTA_ID"))).getAttribute("value"));
	  assertEquals("Hi..There..001", driver.findElement(By.name(prop.getProperty("Txt_Edit_Another_Profile_Password"))).getAttribute("value"));    
	  assertEquals("manager@gmail.com", driver.findElement(By.name(prop.getProperty("Txt_Edit_Another_Profile_Email"))).getAttribute("value"));    
	  assertEquals("35", driver.findElement(By.name(prop.getProperty("Txt_Edit_Another_Profile_Age"))).getAttribute("value"));     
	    
	  //Click logout 
	  driver.findElement(By.linkText(prop.getProperty("Lnk_Edit_Another_Profile_Logout"))).click();  
  }
  
  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}
