package car_rental_app.functions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import java.util.Properties;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import static org.junit.Assert.*;
import car_rental_app.data.CarDAO;
import car_rental_app.data.ReservationDAO;
import car_rental_app.data.UserDAO;
import car_rental_app.model.Car;
import car_rental_app.model.ReservationDetails;
import car_rental_app.model.User;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class App_BusinessFunctions {
	
  public static WebDriver driver;
  public static Properties prop;
	
  public void App_BF_Login(WebDriver driver, String sUsername, String sPassword)
  {
	//provide user-name
	driver.findElement(By.id(prop.getProperty("Txt_Login_Username"))).clear();
	driver.findElement(By.id(prop.getProperty("Txt_Login_Username"))).sendKeys(sUsername);
	//provide password
	driver.findElement(By.id(prop.getProperty("Txt_Login_Password"))).clear();
	driver.findElement(By.id(prop.getProperty("Txt_Login_Password"))).sendKeys(sPassword);
	//click on login
	driver.findElement(By.id(prop.getProperty("Btn_Login_Login"))).click();
  }
   
  public void App_BF_Logout(WebDriver driver) {
	  //click on logout link
		driver.findElement(By.linkText(prop.getProperty("Lnk_Home_Logout"))).click();
  }

  public void App_BF_Homepage(WebDriver driver){
	  //click on goto Homepage
	  driver.findElement(By.linkText(prop.getProperty("Lnk_Home_Homepage"))).click();
  }
    
  public void App_BF_Register(WebDriver driver, String firstName, String lastName, String utaId, 
		  String username, String password, String email, String age, String aac, String role) {
	    //enter form data
	    driver.findElement(By.name(prop.getProperty("Txt_Register_First_Name"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Register_First_Name"))).sendKeys(firstName);
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Last_Name"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Last_Name"))).sendKeys(lastName);
	    driver.findElement(By.name(prop.getProperty("Txt_Register_UTA_ID"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Register_UTA_ID"))).sendKeys(utaId);
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Username"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Username"))).sendKeys(username);
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Password"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Password"))).sendKeys(password);
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Email"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Email"))).sendKeys(email);
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Age"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Age"))).sendKeys(age);
	    //choose role
	    if(role.equalsIgnoreCase("Customer"))
	    	driver.findElement(By.id(prop.getProperty("Rad_Register_Role_Customer"))).click();
	    else if (role.equalsIgnoreCase("Manager"))
	    	driver.findElement(By.id(prop.getProperty("Rad_Register_Role_Manager"))).click();
	    else
	    	driver.findElement(By.id(prop.getProperty("Rad_Register_Role_Admin"))).click();
	    //choose aac membership
	    if(aac.equalsIgnoreCase("yes"))
	    	driver.findElement(By.id(prop.getProperty("Rad_Register_AAC_Yes"))).click();
	    else
	    	driver.findElement(By.id(prop.getProperty("Rad_Register_AAC_No"))).click();
	    //submit form
	    driver.findElement(By.id(prop.getProperty("Btn_Register_Register"))).click(); 
  }
  
  public void App_BF_Add_New_Car(WebDriver driver, String carName, String capacity, String weekdayRate, 
		  String weekendRate, String weeklyRate, String dailyGps, String dailyOnstar, String dailySirius) {
	    //enter form data
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Name"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Name"))).sendKeys(carName);
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Capacity"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Capacity"))).sendKeys(capacity);
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Weekday_Rate"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Weekday_Rate"))).sendKeys(weekdayRate);
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Weekend_Rate"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Weekend_Rate"))).sendKeys(weekendRate);
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Weekly_Rate"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Weekly_Rate"))).sendKeys(weeklyRate);
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Daily_Gps"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Daily_Gps"))).sendKeys(dailyGps);
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Daily_Onstar"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Daily_Onstar"))).sendKeys(dailyOnstar);
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Daily_Sirius"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Daily_Sirius"))).sendKeys(dailySirius);
	    //submit form
	    driver.findElement(By.name(prop.getProperty("Btn_Add_Car_Add_Car"))).click(); 
  }
   
  public void App_BF_Revoke_Renter(WebDriver driver, String username) {
	    //enter username
	    driver.findElement(By.name(prop.getProperty("Txt_Revoke_Username"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Revoke_Username"))).sendKeys(username);
	    //submit username
	    driver.findElement(By.name(prop.getProperty("Btn_Revoke_Revoke"))).click(); 
  }
  
  public void App_BF_Find_User_Profile(WebDriver driver, String username) {
	    //enter username
	    driver.findElement(By.name(prop.getProperty("Txt_Find_Profile_Username"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Find_Profile_Username"))).sendKeys(username);
	    //search username
	    driver.findElement(By.name(prop.getProperty("Btn_Find_Profile_Search"))).click(); 
}
  
  public void App_BF_Edit_Profile(WebDriver driver, String firstName, String lastName, String utaId, 
		  String password, String email, String age, String aac) {
	    //enter form data
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_First_Name"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_First_Name"))).sendKeys(firstName);
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Last_Name"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Last_Name"))).sendKeys(lastName);
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_UTA_ID"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_UTA_ID"))).sendKeys(utaId);
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Password"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Password"))).sendKeys(password);
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Email"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Email"))).sendKeys(email);
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Age"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Age"))).sendKeys(age);
	    //choose aac membership
	    if(aac.equalsIgnoreCase("yes"))
	    	driver.findElement(By.id(prop.getProperty("Rad_Edit_Own_Profile_AAC_Yes"))).click();
	    else
	    	driver.findElement(By.id(prop.getProperty("Rad_Edit_Own_Profile_AAC_No"))).click();
	    //submit form
	    driver.findElement(By.name(prop.getProperty("Btn_Edit_Own_Profile_Save"))).click();
	  
  } 
  
  
  
  public void App_BF_ViewAllReservations(WebDriver driver) {
	  List<WebElement> table_contents= new ArrayList<>();
	  ArrayList<ReservationDetails> allReservations = new ArrayList();
	  allReservations = ReservationDAO.getAllReservations();
	  table_contents = driver.findElements(By.tagName("tr"));
	  //Check if error messages are set properly			    
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_View_All_Reservations_Form_Error"))).getAttribute("value"));
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_View_All_Reservations_Start_Error"))).getAttribute("value"));
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_View_All_Reservations_End_Error"))).getAttribute("value"));
	  //Check if all records are shown
	  assertEquals(table_contents.size()-4, allReservations.size());
  }
  
  public void App_BF_ViewAllReservations_Filter(WebDriver driver,String searchStart,String searchEnd) {
	  List<WebElement> table_contents= new ArrayList<>();
	  ArrayList<ReservationDetails> allReservations = new ArrayList();
	  driver.findElement(By.name(prop.getProperty("Txt_View_All_Reservations_Start"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_View_All_Reservations_Start"))).sendKeys(searchStart);
	  driver.findElement(By.name(prop.getProperty("Txt_View_All_Reservations_End"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_View_All_Reservations_End"))).sendKeys(searchEnd);
	  driver.findElement(By.name(prop.getProperty("Btn_View_All_Reservations_Filter"))).click();
	  
	  allReservations = ReservationDAO.getAllReservationsByDate(searchStart, searchEnd);
	  table_contents = driver.findElements(By.tagName("tr"));
	  //Check if all records are shown
	  if(searchStart!="" && searchEnd!="" && driver.findElement(By.xpath("html/body/input")).getText() == "")
		  assertEquals(table_contents.size()-4, allReservations.size());
  }

  public void App_BF_ViewAvailableCars_Filter(WebDriver driver,String searchStart,String searchEnd) {
	  List<WebElement> table_contents= new ArrayList<>();
	  ArrayList<Car> allAvailableCars = new ArrayList();
	  								
	  driver.findElement(By.name(prop.getProperty("Txt_View_Available_Start"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_View_Available_Start"))).sendKeys(searchStart);
	  driver.findElement(By.name(prop.getProperty("Txt_View_Available_End"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_View_Available_End"))).sendKeys(searchEnd);
	  driver.findElement(By.name(prop.getProperty("Btn_View_Available_Search"))).click();
	  
	  allAvailableCars = CarDAO.getAllAvailableCars(searchStart, searchEnd);
	  table_contents = driver.findElements(By.tagName("tr"));
	  //Check if all records are shown
	  if(searchStart!="" && searchEnd!="" && driver.findElement(By.xpath("html/body/input")).getText() == "")
		  assertEquals(table_contents.size()-4, allAvailableCars.size());
  }
  
  public void App_BF_ViewAllCars(WebDriver driver) {
	  List<WebElement> table_contents= new ArrayList<>();
	  ArrayList<Car> allCars = new ArrayList();
	  allCars = CarDAO.getAllCars();
	  table_contents = driver.findElements(By.tagName("tr"));
	  //Check if all records are shown
	  assertEquals(table_contents.size()-1, allCars.size());
	  //Check if first record matches with the Database entry
	  if(table_contents.size()>1)
	  {
		  String carName = driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[1]")).getText();
		  String capacity = driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[2]")).getText();
		  String weekdayRate = driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[3]")).getText();
		  String weekendRate = driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[4]")).getText();
		  String weeklyRate = driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[5]")).getText();
		  String gps = driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[6]")).getText();
		  String onStar = driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[7]")).getText();
		  String sirius = driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[8]")).getText();
		  Iterator carIter = allCars.iterator();
		  while(carIter.hasNext())
		  {
			  Car carObj = (Car)carIter.next();
			  
			  if(carObj.getName().equals(carName))
			  {
				  assertEquals(carObj.getName(),carName);
				  assertEquals(carObj.getCapacity(),Integer.parseInt(capacity));
				  assertEquals(carObj.getWeekdayRate(),Double.parseDouble(weekdayRate.replace("$", "")),0);
				  assertEquals(carObj.getWeekendRate(),Double.parseDouble(weekendRate.replace("$", "")),0);
				  assertEquals(carObj.getWeeklyRate(),Double.parseDouble(weeklyRate.replace("$", "")),0);
				  assertEquals(carObj.getDailyGps(),Double.parseDouble(gps.replace("$", "")),0);
				  assertEquals(carObj.getDailyOnstar(),Double.parseDouble(onStar.replace("$", "")),0);
				  assertEquals(carObj.getDailySirius(),Double.parseDouble(sirius.replace("$", "")),0);
			  }
		  }
		  
	  }
	  
  }
  
  public void App_BF_ViewUserReservations(WebDriver driver,String userName) {
	  List<WebElement> table_contents= new ArrayList<>();
	  ArrayList<ReservationDetails> allReservations = new ArrayList();
	  User userObj = new User();
	  userObj = UserDAO.getUser(userName);
	  allReservations = ReservationDAO.getAllMyReservations(userObj.getId());
	  table_contents = driver.findElements(By.tagName("tr"));
	  //Check if error messages are set properly
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_View_My_Reservations_Form_Error"))).getText());
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_View_My_Reservations_Start_Error"))).getText());
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_View_My_Reservations_End_Error"))).getText());
	  //Check if all records are shown
	  assertEquals(table_contents.size()-4, allReservations.size());
  }
  
  public void App_BF_ViewUserReservations_Filter(WebDriver driver,String searchStart,String searchEnd,String userName) {
	  List<WebElement> table_contents= new ArrayList<>();
	  ArrayList<ReservationDetails> allReservations = new ArrayList();
	  User userObj = new User();
	  userObj = UserDAO.getUser(userName);

	  driver.findElement(By.name(prop.getProperty("Txt_View_My_Reservations_Start"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_View_My_Reservations_Start"))).sendKeys(searchStart);
	  driver.findElement(By.name(prop.getProperty("Txt_View_My_Reservations_End"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_View_My_Reservations_End"))).sendKeys(searchEnd);
	  driver.findElement(By.name(prop.getProperty("Btn_View_My_Reservations_Filter"))).click();
	  
	  allReservations = ReservationDAO.getAllMyReservationsByDate(userObj.getId(),searchStart, searchEnd);
	  table_contents = driver.findElements(By.tagName("tr"));
	  //Check if all records are shown
	  if(searchStart!="" && searchEnd!="" && driver.findElement(By.xpath("html/body/input")).getText() == "")
		  assertEquals(table_contents.size()-4, allReservations.size());
  }
  
  public void App_BF_RequestRental_Filter(WebDriver driver,String searchStart,String searchEnd,String capacity) {
	  List<WebElement> table_contents= new ArrayList<>();
	  ArrayList<Car> filteredCars = new ArrayList();

	  driver.findElement(By.name(prop.getProperty("Txt_Request_Rental_Start"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_Request_Rental_Start"))).sendKeys(searchStart);
	  driver.findElement(By.name(prop.getProperty("Txt_Request_Rental_End"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_Request_Rental_End"))).sendKeys(searchEnd);
	  driver.findElement(By.name(prop.getProperty("Txt_Request_Rental_Capacity"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_Request_Rental_Capacity"))).sendKeys(capacity);
	  driver.findElement(By.name(prop.getProperty("Btn_Request_Rental_Search"))).click();
	  
	  if(capacity != "")
		  filteredCars = CarDAO.getAvailableCarsCustomer(Integer.parseInt(capacity),searchStart, searchEnd);
	  table_contents = driver.findElements(By.tagName("tr"));
	  //Check if all records are shown
	  if(searchStart!="" && searchEnd!="" && capacity != "" && driver.findElement(By.xpath("html/body/input[2]")).getText() == "")
		  assertEquals(table_contents.size()-5, filteredCars.size());
  }
  
  public void App_BF_AddFeatures(WebDriver driver,Boolean gps,Boolean onStar,Boolean siriusXM, Boolean nextStep) {
	  assertEquals("Add Features",driver.getTitle());
	  String featureStr = "";
	  if(gps)
	  {
		  driver.findElement(By.xpath(prop.getProperty("Chck_Add_Features_GPS"))).click();
		  featureStr += "GPS"; 
	  }
	  if(onStar)
	  {
		  driver.findElement(By.xpath(prop.getProperty("Chck_Add_Features_Onstar"))).click();
		  featureStr += "OnStar";
	  }
	  if(siriusXM)
	  {
		  driver.findElement(By.xpath(prop.getProperty("Chck_Add_Features_Sirius"))).click();
		  featureStr += "SiriusXM";
	  }
	  if(nextStep)
	  {
		  driver.findElement(By.name(prop.getProperty("Btn_Add_Features_Continue"))).click();
		  assertEquals(featureStr,driver.findElement(By.xpath(prop.getProperty("Lbl_Payment_Page_Extras"))).getText());
	  }
	  else
		  driver.findElement(By.name(prop.getProperty("Btn_Add_Features_Back"))).click();
  }
  
  public void App_BF_Payment(WebDriver driver,String nameOnCard ,String cardNumber ,String cardExpriration ,String cvv) {
 
	  driver.findElement(By.name(prop.getProperty("Txt_Payment_Name_On_Card"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_Payment_Name_On_Card"))).sendKeys(nameOnCard);
	  driver.findElement(By.name(prop.getProperty("Txt_Payment_Card_Number"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_Payment_Card_Number"))).sendKeys(cardNumber);
	  driver.findElement(By.name(prop.getProperty("Txt_Payment_Card_Expires"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_Payment_Card_Expires"))).sendKeys(cardExpriration);
	  driver.findElement(By.name(prop.getProperty("Txt_Payment_CCV"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_Payment_CCV"))).sendKeys(cvv);
	  driver.findElement(By.name(prop.getProperty("Btn_Payment_Pay"))).click();
	  
	  if(driver.getTitle().equals("Payment Confirmation"))
	  {
		  int resID = Integer.parseInt(driver.findElement(By.xpath("html/body/table/tbody/tr[1]/td[2]")).getText());
		  ReservationDetails rd = new ReservationDetails();
		  rd =  ReservationDAO.getReservationById(resID);
		  assertEquals(driver.findElement(By.xpath("html/body/table/tbody/tr[1]/td[2]")).getText(),Integer.toString(rd.getId()));
		  assertEquals(driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[2]")).getText(),rd.getCarName());
		  assertEquals(driver.findElement(By.xpath("html/body/table/tbody/tr[3]/td[2]")).getText(),Integer.toString(rd.getCapacity()));	
		  assertEquals(driver.findElement(By.xpath("html/body/table/tbody/tr[6]/td[2]")).getText(),rd.getAdditionalFeatures());
		  assertEquals(driver.findElement(By.xpath("html/body/table/tbody/tr[7]/td[2]")).getText(),"$"+Double.toString(rd.getTotalPrice()));
		  driver.findElement(By.linkText(prop.getProperty("Lnk_Home_Homepage"))).click();
	  }
  }
   
}
